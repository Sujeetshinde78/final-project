import React from "react";
//import { Component } from "react";
import "./cssfooter.css";

function Footer() {
  return (
    <div  className="divfooter">
      <footer className='footer'>
            <span className='text-muted'>All Rights Reserved 2022 @HouseHelpers.</span>
        </footer>
    </div>
  );
}

export default Footer;

